from subprocess import call
import os

params = "2 3 4 5"

cwd = "python " +os.getcwd()
progDir = "\\exec_dummy.py"


finalDir = cwd+"\\Functions"+progDir
print(finalDir)

