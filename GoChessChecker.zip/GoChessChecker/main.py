import Classes.Routine as game

game.game_io()
