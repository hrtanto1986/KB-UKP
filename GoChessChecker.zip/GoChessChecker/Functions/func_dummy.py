

def foo(board):
    #do calc here
    response = ''
    return response

def bar(board):
    #do calc here
    response = ''
    return response