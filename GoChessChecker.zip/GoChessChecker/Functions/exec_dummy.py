import sys


print('wow')